#!/usr/bin/python3

#Import library
import irc # For working with irc
import nltk
from irc import bot
import random as rand
from time import time, sleep # Delay between utterance
import time
import threading # Multithreading
import collections # For default dict
import sys  # Parse arguments
from nltk.corpus import wordnet as wn


class TestBot(irc.bot.SingleServerIRCBot):
    def __init__(self, channel, nickname, server, delaytime, utterance_lst, utterance_lst_lower, port=6667):
        irc.bot.SingleServerIRCBot.__init__(self, [(server, port)], nickname, nickname)
        self.channel = channel
        self.phase = "0"
        self.msgs = []
        self.nickname = nickname
        self.target = ""
        self.delaytime = delaytime
        self.last_respond = int(round(time.time()))
        self.utterance_lst = utterance_lst
        self.utterance_lst_lower = utterance_lst_lower
    
    def on_welcome(self, c, e):
        c.join(self.channel)
    
    def on_privmsg(self, c, e):
        self.msgs.append((e, e.arguments[0]))
    
    def on_pubmsg(self, c, e):
        a = e.arguments[0].split(":", 1)
        if len(a) > 1 and irc.strings.lower(a[0]) == irc.strings.lower(self.connection.get_nickname()):
            #self.do_command(e, a[1].strip())
            self.msgs.append((e, a[1].strip()))
            # Exit this thread if die
            if(a[1].strip() == "die"):
                c.privmsg(self.channel,"ohh... will miss you :(" )
                self.die()
        return

    def do_command(self, e, cmd):
    # If begin the new conversation
        if self.phase == "0":
            self.target = e.source.nick
        nick = e.source.nick
        #self.target = nick
        c = self.connection
        
        if cmd == "disconnect":
            self.disconnect()
        elif cmd == "die":
            self.die()
        elif cmd == "forget":
            self.phase = "0"
            self.target = ""
            sleep(2)
            c.privmsg(self.channel, nick + ": Virus crashed my memory... Begin a new conversation")
            self.last_respond = int(round(time.time()))
        elif cmd == "users":
            for chname, chobj in self.channels.items():
                users = sorted(chobj.users())
                c.privmsg(self.channel, "Users: " + ", ".join(users))
        elif self.phase == "5":
            sleep(2)
            c.privmsg(self.channel, nick + ": I just finished a coversation, send me a forget command to start a new conversation")
            self.last_respond = int(round(time.time()))
        else:
            # Do nothing when target is not the person we are talking rn
            if nick != self.target:
                sleep(2)
                c.privmsg(self.channel, nick + ": Sorry I'm currently talking to " + self.target + ". Send me a forget command to get me from " + self.target)
            else:
                # Someone greeting you
                if (cmd.lower() in self.utterance_lst_lower[0]) and self.phase == "0":
                    #c.notice(nick, nick + ": Hello back at you!")
                    sleep(2)
                    c.privmsg(self.channel, nick + ": " + rand.choice(self.utterance_lst[2]))
                    self.phase = "2"
                    self.last_respond = int(round(time.time()))
                # Someone hello back at you
                elif cmd.lower() in self.utterance_lst_lower[7]:
                    pass
                elif ((cmd.lower() in self.utterance_lst_lower[2])
                      and self.phase.startswith("1-")):
                    #c.notice(nick, nick + ": How are you?")
                    sleep(2)
                    c.privmsg(self.channel, nick + ": " + rand.choice(self.utterance_lst[3]))
                    self.phase = "3-0"
                    self.last_respond = int(round(time.time()))
                # Someone inquiry you
                elif cmd.lower() in self.utterance_lst_lower[3] and self.phase == "2":
                    #c.notice(nick, nick + ": I'm good")
                    sleep(2)
                    c.privmsg(self.channel, nick + ": " + rand.choice(self.utterance_lst[4]))
                    #c.notice(nick, nick + ": How about you?")
                    sleep(2)
                    c.privmsg(self.channel, nick + ": " + rand.choice(self.utterance_lst[5]))
                    self.phase = "4"
                    self.last_respond = int(round(time.time()))
                # Someone answer inquiry and inquiry back at you
                elif cmd.lower() in self.utterance_lst_lower[4] and self.phase == "3-0":
                    self.phase = "3-1"
                elif cmd.lower() in self.utterance_lst_lower[5] and self.phase == "3-1":
                    #c.notice(nick, nick + ": I'm good")
                    sleep(2)
                    c.privmsg(self.channel, nick + ": " + rand.choice(self.utterance_lst[6]))
                    #c.notice(nick, nick + ": Ok, bye!")
                    sleep(1)
                    c.privmsg(self.channel, nick + ": " + rand.choice(self.utterance_lst[7]))
                    self.phase = "0"
                    self.last_respond = int(round(time.time()))
                elif cmd.lower() in self.utterance_lst_lower[6] and self.phase == "4":
                    #c.notice(nick, nick + ": Ok, bye!")
                    sleep(2)
                    c.privmsg(self.channel, nick + ": " + rand.choice(self.utterance_lst[7]))
                    self.phase = "0"
                    self.last_respond = int(round(time.time()))
                elif 'inbox' in cmd.lower()[:5]:
                    c.notice(cmd.split(' ')[1],cmd.split(' ')[2])
                elif 'define' in cmd.lower()[:6]:
                     c.privmsg(self.channel, nick + ": " + rand.choice(wn.synsets(cmd.lower().split(' ')[1])).definition())

                else:
                    sleep(2)
                    c.privmsg(self.channel, "I have no idea what you meant by " + cmd +" But my resources say that :")
                    for i in cmd.split(' '):
                        if len(wn.synsets(i))>1:
                            c.privmsg(self.channel, i + ' means ' + rand.choice(wn.synsets(i)).definition())


                    self.last_respond = int(round(time.time()))

    def run(self):
        thread1 = threading.Thread(target = self.start)
        thread1.start()
        while not len(self.channels.items()) > 0:
            continue
        sleep(5)
        while True:
            # If there is no respond in the given time
            if(len(self.msgs) == 0 and (int(round(time.time())) - self.last_respond) > self.delaytime):
                c = self.connection
                # First initial outreach
                if self.phase == "0":
                    users = list(self.channels[self.channel].users())
                    if(len(users) > 1):
                        users.remove(self.nickname)
                    
                    bot_users = []
                    for user in users:
                        if user.endswith("-bot"):
                            bot_users.append(user)

                    if len(bot_users) > 0:
                        self.target = rand.choice(bot_users)
                    else:
                        self.target = rand.choice(users)
                    
                    #c.notice(self.target,self.target + ": hi")
                    c.privmsg(self.channel, self.target + ": " + rand.choice(self.utterance_lst[0]))
                    self.phase = "1-0"
                    self.last_respond = int(round(time.time()))
                # Secondary Outreach
                elif self.phase == "1-0":
                    #c.notice(self.target,self.target + ": I said hi")
                    c.privmsg(self.channel, self.target + ": " + rand.choice(self.utterance_lst[1]))
                    self.phase = "1-1"
                    self.last_respond = int(round(time.time()))
                # Give up frustrated when not reply after:
                # Secondary outreach (1): phase 1-1
                # Outreach reply (2): phase 2
                # Inquiry (1): phase 3
                # Inquiry (2): phase 4
                elif self.phase == "1-1" or self.phase == "2" or self.phase == "3-0" or self.phase == "3-1" or self.phase == "4":
                    #c.notice(self.target,self.target + ": Ok, forget you. Bye!")
                    c.privmsg(self.channel, self.target + ": " + rand.choice(self.utterance_lst[8]))
                    # Set to end phase
                    self.phase = "0"
                    self.last_respond = int(round(time.time()))
            
            # If get some responds
            else:
                # Check if die command given
                for msg in self.msgs:
                    if(msg[1] == "die"):
                        thread1.join()
                        return
                for msg in self.msgs:
                    self.do_command(msg[0], msg[1])
                    self.msgs.remove(msg)
            #sleep(self.delaytime)

def check_bot_name(bot_name):
    return bot_name.endswith('-bot')

def main():
    if len(sys.argv) != 5 and len(sys.argv) != 6:
        print("Usage: mybot <server> <channel> <nickname> <text_input_file> <Optional[DelayTime]>")
        sys.exit(1)
    
    server = sys.argv[1]
    channel = sys.argv[2]
    nickname = sys.argv[3]
    port = 6667

    #Process input file
    utterance_lst = [] # List of utterance sentences works for this bot (can understand)
    utterance_lst_lower = [] # Same but in lower character
    input_file_name = sys.argv[4]
    try:
        f = open(input_file_name,"r")
    except IOError as e:
        print ("I/O error({0}): {1}".format(e.errno, e.strerror))
        sys.exit(1)
    lines = f.readlines()
    for line in lines:
        tmp_lst = [sen.strip() for sen in line.split("|")]
        utterance_lst.append(tmp_lst)
        tmp_lst_lower = [sen.lower() for sen in tmp_lst]
        utterance_lst_lower.append(tmp_lst_lower)
    f.close()

    delaytime = 30 # Time between utterances
    if len(sys.argv) == 6:
        delaytime = int(sys.argv[5])

    ### Test bot name
    if(not check_bot_name(nickname)):
        print('bot name must end with -bot')
        sys.exit(1)
    bot = TestBot(channel, nickname, server,delaytime, utterance_lst, utterance_lst_lower, port)
    bot.run()


if __name__ == "__main__":
    main()
