download the source code along wih the text_input file
run the following command

python <pythonfilename.py> chat.freenode.net <channel name> <botname> text_input.txt <Optional[DelayTime]>

go to webchat.freenode.net create a nick name and enter the channel to montor or start a conversation with the bot
